import { useState, useRef } from "react";
import { useStoreConfig } from "@/contexts/StoreConfigContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Info, Upload, X } from "lucide-react";
import { toast } from "sonner";

const LOGO_SIZES = {
  recommended: "200×60px",
  format: "PNG com fundo transparente",
  maxSize: "500KB",
};

const AdminSettings = () => {
  const { config, updateStoreName, updateLogoUrl, updateWhatsappNumber, updateFooter } = useStoreConfig();

  const [storeName, setStoreName] = useState(config.storeName);
  const [logoUrl, setLogoUrl] = useState(config.logoUrl);
  const [whatsapp, setWhatsapp] = useState(config.whatsappNumber);
  const [footer, setFooter] = useState(config.footer);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 512000) {
      toast.error("Arquivo muito grande. Máximo 500KB.");
      return;
    }

    if (!file.type.startsWith("image/")) {
      toast.error("Selecione um arquivo de imagem.");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setLogoUrl(reader.result as string);
      toast.success("Logo carregada!");
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveLogo = () => {
    setLogoUrl("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSave = () => {
    updateStoreName(storeName);
    updateLogoUrl(logoUrl);
    updateWhatsappNumber(whatsapp);
    updateFooter(footer);
    toast.success("Configurações salvas!");
  };

  return (
    <div className="space-y-8">
      {/* Logo */}
      <div className="bg-card p-5 rounded-lg border space-y-4">
        <h3 className="font-display text-lg font-semibold">Logo da Loja</h3>
        <div className="bg-secondary/50 p-3 rounded-md border flex items-start gap-2">
          <Info className="h-4 w-4 text-primary mt-0.5 shrink-0" />
          <div className="text-sm text-muted-foreground">
            <p><strong>Tamanho recomendado:</strong> {LOGO_SIZES.recommended}</p>
            <p><strong>Formato:</strong> {LOGO_SIZES.format}</p>
            <p><strong>Tamanho máximo:</strong> {LOGO_SIZES.maxSize}</p>
          </div>
        </div>

        {/* File Upload */}
        <div className="space-y-2">
          <Label>Enviar arquivo</Label>
          <div className="flex gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />
            <Button
              type="button"
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2"
            >
              <Upload className="h-4 w-4" />
              Escolher arquivo
            </Button>
            {logoUrl && (
              <Button type="button" variant="ghost" size="icon" onClick={handleRemoveLogo}>
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>

        {/* URL fallback */}
        <div className="space-y-2">
          <Label>Ou cole a URL</Label>
          <Input value={logoUrl.startsWith("data:") ? "" : logoUrl} onChange={(e) => setLogoUrl(e.target.value)} placeholder="https://... (deixe vazio para usar texto)" />
        </div>

        {logoUrl && (
          <div className="p-3 bg-muted rounded-md">
            <p className="text-xs text-muted-foreground mb-2">Preview:</p>
            <img src={logoUrl} alt="Logo preview" className="h-12 object-contain" />
          </div>
        )}
      </div>

      {/* Store Name */}
      <div className="bg-card p-5 rounded-lg border space-y-4">
        <h3 className="font-display text-lg font-semibold">Nome da Loja</h3>
        <div className="space-y-2">
          <Label>Nome</Label>
          <Input value={storeName} onChange={(e) => setStoreName(e.target.value)} />
        </div>
      </div>

      {/* WhatsApp */}
      <div className="bg-card p-5 rounded-lg border space-y-4">
        <h3 className="font-display text-lg font-semibold">WhatsApp</h3>
        <div className="space-y-2">
          <Label>Número (com código do país, ex: 5511999999999)</Label>
          <Input value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} placeholder="5511999999999" />
          <p className="text-xs text-muted-foreground">Use apenas números. Ex: 55 (Brasil) + DDD + número</p>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-card p-5 rounded-lg border space-y-4">
        <h3 className="font-display text-lg font-semibold">Rodapé</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Nome no Rodapé</Label>
            <Input value={footer.storeName} onChange={(e) => setFooter({ ...footer, storeName: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label>Email</Label>
            <Input value={footer.email} onChange={(e) => setFooter({ ...footer, email: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label>WhatsApp (exibição)</Label>
            <Input value={footer.whatsappDisplay} onChange={(e) => setFooter({ ...footer, whatsappDisplay: e.target.value })} placeholder="(11) 99999-9999" />
          </div>
        </div>
        <div className="space-y-2">
          <Label>Descrição</Label>
          <Textarea value={footer.description} onChange={(e) => setFooter({ ...footer, description: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>Copyright</Label>
          <Input value={footer.copyright} onChange={(e) => setFooter({ ...footer, copyright: e.target.value })} />
        </div>
      </div>

      <Button variant="hero" size="lg" onClick={handleSave} className="w-full">
        Salvar Todas as Configurações
      </Button>
    </div>
  );
};

export default AdminSettings;
