import { useState } from "react";
import { useStoreConfig } from "@/contexts/StoreConfigContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Category } from "@/types/store";

const AdminCategories = () => {
  const { config, addCategory, updateCategory, removeCategory } = useStoreConfig();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Category | null>(null);
  const [form, setForm] = useState({ name: "", slug: "" });

  const resetForm = () => {
    setForm({ name: "", slug: "" });
    setEditing(null);
    setShowForm(false);
  };

  const handleEdit = (cat: Category) => {
    setEditing(cat);
    setForm({ name: cat.name, slug: cat.slug });
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.slug) {
      toast.error("Preencha todos os campos.");
      return;
    }
    if (editing) {
      updateCategory(editing.id, form);
      toast.success("Categoria atualizada!");
    } else {
      addCategory(form);
      toast.success("Categoria adicionada!");
    }
    resetForm();
  };

  const autoSlug = (name: string) => {
    const slug = name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
    setForm({ name, slug });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="font-display text-lg font-semibold">Categorias ({config.categories.length})</h3>
        <Button variant="hero" size="sm" onClick={() => { resetForm(); setShowForm(true); }}>
          <Plus className="h-4 w-4 mr-1" /> Nova Categoria
        </Button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-card p-5 rounded-lg border space-y-4">
          <h4 className="font-semibold">{editing ? "Editar Categoria" : "Nova Categoria"}</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Nome *</Label>
              <Input value={form.name} onChange={(e) => autoSlug(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label>Slug *</Label>
              <Input value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} required />
            </div>
          </div>
          <div className="flex gap-3">
            <Button type="submit" variant="hero" size="sm">{editing ? "Salvar" : "Adicionar"}</Button>
            <Button type="button" variant="outline" size="sm" onClick={resetForm}>Cancelar</Button>
          </div>
        </form>
      )}

      <div className="space-y-2">
        {config.categories.map((cat) => (
          <div key={cat.id} className="flex gap-4 p-3 bg-card rounded-lg border items-center">
            <div className="flex-1">
              <span className="font-semibold text-foreground">{cat.name}</span>
              <span className="text-sm text-muted-foreground ml-2">({cat.slug})</span>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => handleEdit(cat)}>
                <Pencil className="h-3 w-3" />
              </Button>
              <Button variant="outline" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => { removeCategory(cat.id); toast.success("Removida."); }}>
                <Trash2 className="h-3 w-3" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminCategories;
