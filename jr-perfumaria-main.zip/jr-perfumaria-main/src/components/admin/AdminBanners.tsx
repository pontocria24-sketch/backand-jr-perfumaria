import { useState } from "react";
import { useStoreConfig } from "@/contexts/StoreConfigContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Plus, Pencil, Trash2, Info } from "lucide-react";
import { toast } from "sonner";
import { Banner } from "@/types/store";

const BANNER_SIZES = [
  { device: "📱 Mobile", width: "768px", height: "300px", ratio: "2.56:1" },
  { device: "📱 Tablet", width: "1024px", height: "400px", ratio: "2.56:1" },
  { device: "🖥️ Desktop", width: "1920px", height: "480px", ratio: "4:1" },
];

const AdminBanners = () => {
  const { config, addBanner, updateBanner, removeBanner } = useStoreConfig();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Banner | null>(null);
  const [form, setForm] = useState({ image: "", title: "", subtitle: "", cta: "", active: true });

  const resetForm = () => {
    setForm({ image: "", title: "", subtitle: "", cta: "", active: true });
    setEditing(null);
    setShowForm(false);
  };

  const handleEdit = (banner: Banner) => {
    setEditing(banner);
    setForm({ image: banner.image, title: banner.title, subtitle: banner.subtitle, cta: banner.cta, active: banner.active });
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.image || !form.title) {
      toast.error("Preencha imagem e título.");
      return;
    }
    if (editing) {
      updateBanner(editing.id, form);
      toast.success("Banner atualizado!");
    } else {
      addBanner(form);
      toast.success("Banner adicionado!");
    }
    resetForm();
  };

  return (
    <div className="space-y-6">
      {/* Size guide */}
      <div className="bg-secondary/50 p-4 rounded-lg border space-y-2">
        <div className="flex items-center gap-2 text-foreground font-semibold">
          <Info className="h-4 w-4 text-primary" />
          Tamanhos recomendados para banners
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {BANNER_SIZES.map((s) => (
            <div key={s.device} className="bg-card p-3 rounded-md border text-sm">
              <p className="font-semibold">{s.device}</p>
              <p className="text-muted-foreground">{s.width} × {s.height}</p>
              <p className="text-muted-foreground">Proporção: {s.ratio}</p>
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground">
          💡 Use uma imagem de <strong>1920×480px</strong> para melhor resultado em todos os dispositivos. Formato JPG ou PNG.
        </p>
      </div>

      <div className="flex justify-between items-center">
        <h3 className="font-display text-lg font-semibold">Banners ({config.banners.length})</h3>
        <Button variant="hero" size="sm" onClick={() => { resetForm(); setShowForm(true); }}>
          <Plus className="h-4 w-4 mr-1" /> Novo Banner
        </Button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-card p-5 rounded-lg border space-y-4">
          <h4 className="font-semibold">{editing ? "Editar Banner" : "Novo Banner"}</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>URL da Imagem *</Label>
              <Input value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} placeholder="https://..." required />
            </div>
            <div className="space-y-2">
              <Label>Título *</Label>
              <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
            </div>
            <div className="space-y-2">
              <Label>Subtítulo</Label>
              <Input value={form.subtitle} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Texto do Botão</Label>
              <Input value={form.cta} onChange={(e) => setForm({ ...form, cta: e.target.value })} />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Switch checked={form.active} onCheckedChange={(v) => setForm({ ...form, active: v })} />
            <Label>Banner ativo</Label>
          </div>
          <div className="flex gap-3">
            <Button type="submit" variant="hero" size="sm">{editing ? "Salvar" : "Adicionar"}</Button>
            <Button type="button" variant="outline" size="sm" onClick={resetForm}>Cancelar</Button>
          </div>
        </form>
      )}

      <div className="space-y-3">
        {config.banners.map((banner) => (
          <div key={banner.id} className="flex gap-4 p-4 bg-card rounded-lg border items-center">
            <img src={banner.image} alt={banner.title} className="h-16 w-28 rounded-md object-cover shrink-0" />
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-foreground truncate">{banner.title}</h4>
              <p className="text-sm text-muted-foreground truncate">{banner.subtitle}</p>
              <span className={`text-xs ${banner.active ? "text-primary" : "text-muted-foreground"}`}>
                {banner.active ? "✅ Ativo" : "⏸️ Inativo"}
              </span>
            </div>
            <div className="flex gap-2 shrink-0">
              <Button variant="outline" size="icon" onClick={() => handleEdit(banner)}>
                <Pencil className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={() => { removeBanner(banner.id); toast.success("Banner removido."); }} className="text-destructive hover:text-destructive">
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminBanners;
