import { Product } from "@/types/store";
import { useCart } from "@/contexts/CartContext";
import { Button } from "@/components/ui/button";
import { ShoppingCart, Heart } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { useState } from "react";
import { Link } from "react-router-dom";

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { addItem } = useCart();
  const [liked, setLiked] = useState(false);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem(product);
    toast.success(`${product.name} adicionado à sacola!`);
  };

  const handleLike = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setLiked(!liked);
  };

  const priceFormatted = product.price.toFixed(2).replace(".", ",");

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="group bg-card rounded-none sm:rounded-lg overflow-hidden border-0 sm:border hover:shadow-lg transition-all duration-300"
    >
      <Link to={`/produto/${product.id}`} className="block">
        <div className="relative aspect-square overflow-hidden bg-muted">
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
            loading="lazy"
          />
          <button
            onClick={handleLike}
            className="absolute top-3 right-3 h-8 w-8 rounded-full bg-card/80 backdrop-blur-sm flex items-center justify-center hover:bg-card transition-colors z-10"
          >
            <Heart
              className={`h-4 w-4 transition-colors ${liked ? "fill-destructive text-destructive" : "text-foreground/60"}`}
            />
          </button>
          {product.featured && (
            <span className="absolute top-3 left-3 bg-primary text-primary-foreground text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full">
              Destaque
            </span>
          )}
          <div className="absolute inset-x-0 bottom-0 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
            <Button
              onClick={handleAddToCart}
              className="w-full rounded-none h-11 bg-primary text-primary-foreground hover:bg-accent font-display text-xs uppercase tracking-wider font-semibold"
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              Adicionar à Sacola
            </Button>
          </div>
        </div>

        <div className="p-3 sm:p-4 space-y-1.5">
          <p className="text-[11px] text-muted-foreground uppercase tracking-wider font-medium">
            {product.category}
          </p>
          <h3 className="font-display text-sm sm:text-base font-semibold text-foreground line-clamp-1 group-hover:text-primary transition-colors">
            {product.name}
          </h3>
          <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">
            {product.description.slice(0, 100)}
          </p>
          <div className="pt-1.5">
            <span className="text-lg sm:text-xl font-bold text-foreground font-display">
              R$ {priceFormatted}
            </span>
            <p className="text-[11px] text-muted-foreground">
              ou 3x de R$ {(product.price / 3).toFixed(2).replace(".", ",")} sem juros
            </p>
          </div>
        </div>
      </Link>
    </motion.div>
  );
};

export default ProductCard;
