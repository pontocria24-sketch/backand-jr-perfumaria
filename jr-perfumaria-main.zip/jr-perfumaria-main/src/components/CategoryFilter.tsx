import { Category } from "@/types/store";
import { Sparkles, Flower2, User, Globe, Flag, LayoutGrid } from "lucide-react";

interface CategoryFilterProps {
  categories: Category[];
  selected: string;
  onSelect: (slug: string) => void;
}

const categoryIcons: Record<string, React.ReactNode> = {
  masculino: <User className="h-5 w-5" />,
  feminino: <Flower2 className="h-5 w-5" />,
  unissex: <Sparkles className="h-5 w-5" />,
  importados: <Globe className="h-5 w-5" />,
  nacionais: <Flag className="h-5 w-5" />,
};

const CategoryFilter = ({ categories, selected, onSelect }: CategoryFilterProps) => {
  return (
    <div className="flex flex-wrap justify-center gap-3 sm:gap-6">
      <button
        onClick={() => onSelect("")}
        className={`flex flex-col items-center gap-2 px-4 py-3 rounded-xl transition-all duration-200 min-w-[80px] ${
          selected === ""
            ? "bg-primary text-primary-foreground shadow-md"
            : "bg-muted text-foreground hover:bg-primary/10 hover:text-primary"
        }`}
      >
        <LayoutGrid className="h-5 w-5" />
        <span className="text-xs font-semibold uppercase tracking-wider">Todos</span>
      </button>
      {categories.map((cat) => (
        <button
          key={cat.id}
          onClick={() => onSelect(cat.slug)}
          className={`flex flex-col items-center gap-2 px-4 py-3 rounded-xl transition-all duration-200 min-w-[80px] ${
            selected === cat.slug
              ? "bg-primary text-primary-foreground shadow-md"
              : "bg-muted text-foreground hover:bg-primary/10 hover:text-primary"
          }`}
        >
          {categoryIcons[cat.slug] || <Sparkles className="h-5 w-5" />}
          <span className="text-xs font-semibold uppercase tracking-wider">{cat.name}</span>
        </button>
      ))}
    </div>
  );
};

export default CategoryFilter;
