import { useStoreConfig } from "@/contexts/StoreConfigContext";
import { MapPin, Mail, Phone, Instagram, Facebook } from "lucide-react";

const Footer = () => {
  const { config } = useStoreConfig();
  const { footer } = config;

  return (
    <footer className="bg-foreground text-card mt-16">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="font-display text-xl font-extrabold uppercase tracking-tight">
              {footer.storeName}
            </h3>
            <p className="text-sm text-card/60 leading-relaxed">{footer.description}</p>
            <div className="flex gap-3 pt-2">
              <a href="#" className="h-9 w-9 rounded-full bg-card/10 flex items-center justify-center hover:bg-primary transition-colors">
                <Instagram className="h-4 w-4" />
              </a>
              <a href="#" className="h-9 w-9 rounded-full bg-card/10 flex items-center justify-center hover:bg-primary transition-colors">
                <Facebook className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-display font-bold uppercase text-sm tracking-wider mb-4">Navegação</h4>
            <ul className="space-y-2.5 text-sm text-card/60">
              <li><a href="/" className="hover:text-card transition-colors">Início</a></li>
              <li><a href="/" className="hover:text-card transition-colors">Promoções</a></li>
              <li><a href="/" className="hover:text-card transition-colors">Lançamentos</a></li>
              <li><a href="/login" className="hover:text-card transition-colors">Minha Conta</a></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-display font-bold uppercase text-sm tracking-wider mb-4">Categorias</h4>
            <ul className="space-y-2.5 text-sm text-card/60">
              {config.categories.slice(0, 5).map((cat) => (
                <li key={cat.id}>
                  <a href="/" className="hover:text-card transition-colors">{cat.name}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display font-bold uppercase text-sm tracking-wider mb-4">Contato</h4>
            <ul className="space-y-3 text-sm text-card/60">
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-primary" />
                {footer.whatsappDisplay}
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-primary" />
                {footer.email}
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-card/10 text-center text-xs text-card/40">
          {footer.copyright}
        </div>
      </div>
    </footer>
  );
};

export default Footer;
