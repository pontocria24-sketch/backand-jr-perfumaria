import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStoreConfig } from "@/contexts/StoreConfigContext";

const BannerCarousel = () => {
  const { config } = useStoreConfig();
  const banners = config.banners.filter((b) => b.active);
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    if (banners.length <= 1) return;
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [banners.length]);

  if (banners.length === 0) return null;

  const prev = () => setCurrent((c) => (c - 1 + banners.length) % banners.length);
  const next = () => setCurrent((c) => (c + 1) % banners.length);

  return (
    <div className="relative w-full h-[240px] sm:h-[360px] lg:h-[480px] overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.div
          key={banners[current].id}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6 }}
          className="absolute inset-0"
        >
          <img
            src={banners[current].image}
            alt={banners[current].title}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-foreground/60 via-foreground/20 to-transparent" />
          <div className="absolute inset-0 flex items-center">
            <div className="container mx-auto px-6 sm:px-12">
              <motion.div
                initial={{ y: 30, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3, duration: 0.5 }}
                className="max-w-md space-y-3 sm:space-y-5"
              >
                <h2 className="font-display text-2xl sm:text-4xl lg:text-5xl font-extrabold text-card leading-tight uppercase tracking-tight">
                  {banners[current].title}
                </h2>
                <p className="text-card/90 text-sm sm:text-base lg:text-lg font-light">
                  {banners[current].subtitle}
                </p>
                {banners[current].cta && (
                  <Button
                    className="bg-card text-foreground hover:bg-card/90 font-display font-semibold text-sm uppercase tracking-wider rounded-full px-8 h-11"
                  >
                    {banners[current].cta}
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                )}
              </motion.div>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {banners.length > 1 && (
        <>
          <button
            onClick={prev}
            className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full bg-card/20 p-2.5 backdrop-blur-sm hover:bg-card/40 transition"
          >
            <ChevronLeft className="h-5 w-5 text-card" />
          </button>
          <button
            onClick={next}
            className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full bg-card/20 p-2.5 backdrop-blur-sm hover:bg-card/40 transition"
          >
            <ChevronRight className="h-5 w-5 text-card" />
          </button>
          <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex gap-2">
            {banners.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`h-2.5 rounded-full transition-all duration-300 ${
                  i === current ? "w-8 bg-card" : "w-2.5 bg-card/40"
                }`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default BannerCarousel;
