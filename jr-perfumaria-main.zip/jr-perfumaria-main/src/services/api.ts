import { Product, Category, Banner } from "@/types/store";

const API_URL = import.meta.env.VITE_API_URL || "/api";

async function request<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const url = `${API_URL}${endpoint}`;

  const headers: Record<string, string> = {};
  if (options?.body) {
    headers["Content-Type"] = "application/json";
  }

  const res = await fetch(url, {
    ...options,
    headers: {
      ...headers,
      ...(options?.headers as Record<string, string>),
    },
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`API error ${res.status}: ${text}`);
  }

  const text = await res.text();
  return text ? JSON.parse(text) : ([] as unknown as T);
}

// ── API Client ──
export const api = {
  products: {
    getAll: () => request<Product[]>("/products"),
    create: (p: Omit<Product, "id">) =>
      request<Product[]>("/products", { method: "POST", body: JSON.stringify(p) }),
    update: (id: string, p: Partial<Product>) =>
      request<Product[]>(`/products/${id}`, { method: "PATCH", body: JSON.stringify(p) }),
    delete: (id: string) =>
      request<void>(`/products/${id}`, { method: "DELETE" }),
  },

  categories: {
    getAll: () => request<Category[]>("/categories"),
    create: (c: Omit<Category, "id">) =>
      request<Category[]>("/categories", { method: "POST", body: JSON.stringify(c) }),
    update: (id: string, c: Partial<Category>) =>
      request<Category[]>(`/categories/${id}`, { method: "PATCH", body: JSON.stringify(c) }),
    delete: (id: string) =>
      request<void>(`/categories/${id}`, { method: "DELETE" }),
  },

  banners: {
    getAll: () => request<Banner[]>("/banners"),
    create: (b: Omit<Banner, "id">) =>
      request<Banner[]>("/banners", { method: "POST", body: JSON.stringify(b) }),
    update: (id: string, b: Partial<Banner>) =>
      request<Banner[]>(`/banners/${id}`, { method: "PATCH", body: JSON.stringify(b) }),
    delete: (id: string) =>
      request<void>(`/banners/${id}`, { method: "DELETE" }),
  },

  settings: {
    get: () => request<Array<{ key: string; value: string }>>("/settings"),
    upsert: (key: string, value: string) =>
      request<Array<{ key: string; value: string }>>("/settings", {
        method: "POST",
        body: JSON.stringify({ key, value }),
      }),
  },
};
