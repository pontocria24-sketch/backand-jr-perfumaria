import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const Login = () => {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isRegister) {
      const success = register(email, password);
      if (success) {
        toast.success("Cadastro realizado com sucesso!");
        navigate("/");
      } else {
        toast.error("Erro ao cadastrar. Verifique os dados.");
      }
    } else {
      const success = login(email, password);
      if (success) {
        toast.success("Login realizado com sucesso!");
        navigate("/");
      } else {
        toast.error("Email ou senha inválidos.");
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="w-full max-w-md space-y-6">
        <Link to="/" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition">
          <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
        </Link>

        <div className="text-center">
          <h1 className="font-display text-3xl font-bold text-primary">JR Perfumaria</h1>
          <p className="text-muted-foreground mt-2">
            {isRegister ? "Crie sua conta" : "Acesse sua conta"}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 bg-card p-6 rounded-lg border shadow-sm">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Senha</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              minLength={4}
            />
          </div>
          <Button type="submit" className="w-full" variant="hero">
            {isRegister ? "Cadastrar" : "Entrar"}
          </Button>
        </form>

        <p className="text-center text-sm text-muted-foreground">
          {isRegister ? "Já tem uma conta?" : "Não tem uma conta?"}{" "}
          <button
            onClick={() => setIsRegister(!isRegister)}
            className="text-primary font-semibold hover:underline"
          >
            {isRegister ? "Fazer login" : "Cadastre-se"}
          </button>
        </p>

        <p className="text-center text-xs text-muted-foreground">
          Admin: admin@jr.com / admin123
        </p>
      </div>
    </div>
  );
};

export default Login;
