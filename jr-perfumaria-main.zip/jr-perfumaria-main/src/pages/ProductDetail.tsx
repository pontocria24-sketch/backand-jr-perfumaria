import { useParams, Link } from "react-router-dom";
import { useStoreConfig } from "@/contexts/StoreConfigContext";
import { useCart } from "@/contexts/CartContext";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { ShoppingCart, ChevronRight, Heart, Truck, ShieldCheck, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";
import { motion } from "framer-motion";

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { config } = useStoreConfig();
  const { addItem } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [liked, setLiked] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const product = config.products.find((p) => p.id === id);

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <Header searchQuery={searchQuery} onSearchChange={setSearchQuery} />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center space-y-4">
            <p className="text-xl font-display font-bold text-foreground">Produto não encontrado</p>
            <Link to="/">
              <Button>Voltar à loja</Button>
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const relatedProducts = config.products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addItem(product);
    }
    toast.success(`${quantity}x ${product.name} adicionado à sacola!`);
  };

  const priceFormatted = product.price.toFixed(2).replace(".", ",");
  const installment = (product.price / 3).toFixed(2).replace(".", ",");

  const categoryLabel = config.categories.find((c) => c.slug === product.category)?.name || product.category;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header searchQuery={searchQuery} onSearchChange={setSearchQuery} />

      <main className="flex-1">
        {/* Breadcrumb */}
        <div className="container mx-auto px-4 py-4">
          <nav className="flex items-center gap-1.5 text-sm text-muted-foreground">
            <Link to="/" className="hover:text-primary transition-colors">Início</Link>
            <ChevronRight className="h-3.5 w-3.5" />
            <span className="hover:text-primary transition-colors cursor-pointer">{categoryLabel}</span>
            <ChevronRight className="h-3.5 w-3.5" />
            <span className="text-foreground font-medium truncate max-w-[200px]">{product.name}</span>
          </nav>
        </div>

        {/* Product */}
        <section className="container mx-auto px-4 pb-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-14">
            {/* Image */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4 }}
              className="relative aspect-square bg-muted rounded-xl overflow-hidden group"
            >
              <img
                src={product.image}
                alt={product.name}
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <button
                onClick={() => setLiked(!liked)}
                className="absolute top-4 right-4 h-10 w-10 rounded-full bg-card/80 backdrop-blur-sm flex items-center justify-center hover:bg-card transition-colors shadow-md"
              >
                <Heart
                  className={`h-5 w-5 transition-colors ${liked ? "fill-destructive text-destructive" : "text-foreground/60"}`}
                />
              </button>
              {product.featured && (
                <span className="absolute top-4 left-4 bg-primary text-primary-foreground text-xs font-bold uppercase tracking-wider px-3 py-1.5 rounded-full">
                  Destaque
                </span>
              )}
            </motion.div>

            {/* Info */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.4, delay: 0.1 }}
              className="flex flex-col"
            >
              <p className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-2">
                {categoryLabel}
              </p>

              <h1 className="font-display text-2xl sm:text-3xl lg:text-4xl font-extrabold text-foreground leading-tight">
                {product.name}
              </h1>

              <div className="mt-6 space-y-1">
                <p className="text-3xl sm:text-4xl font-display font-extrabold text-foreground">
                  R$ {priceFormatted}
                </p>
                <p className="text-sm text-muted-foreground">
                  ou <span className="font-semibold text-foreground">3x de R$ {installment}</span> sem juros
                </p>
              </div>

              <div className="mt-8">
                <p className="text-sm font-semibold text-foreground mb-2">Descrição</p>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {product.description}
                </p>
              </div>

              {/* Quantity + Add to cart */}
              <div className="mt-8 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                <div className="flex items-center border rounded-full overflow-hidden">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="h-12 w-12 flex items-center justify-center text-lg font-semibold hover:bg-muted transition-colors"
                  >
                    −
                  </button>
                  <span className="h-12 w-12 flex items-center justify-center font-display font-bold text-lg">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="h-12 w-12 flex items-center justify-center text-lg font-semibold hover:bg-muted transition-colors"
                  >
                    +
                  </button>
                </div>

                <Button
                  onClick={handleAddToCart}
                  className="flex-1 h-12 rounded-full bg-primary text-primary-foreground hover:bg-accent font-display text-sm uppercase tracking-wider font-bold"
                >
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Adicionar à Sacola
                </Button>
              </div>

              {/* Benefits */}
              <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="flex items-center gap-3 p-3 rounded-xl bg-muted">
                  <Truck className="h-5 w-5 text-primary shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-foreground">Frete Grátis</p>
                    <p className="text-[10px] text-muted-foreground">Acima de R$ 199</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-xl bg-muted">
                  <ShieldCheck className="h-5 w-5 text-primary shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-foreground">100% Original</p>
                    <p className="text-[10px] text-muted-foreground">Garantia de autenticidade</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-xl bg-muted">
                  <RotateCcw className="h-5 w-5 text-primary shrink-0" />
                  <div>
                    <p className="text-xs font-semibold text-foreground">Troca Fácil</p>
                    <p className="text-[10px] text-muted-foreground">Até 30 dias</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <section className="bg-muted/50 py-12">
            <div className="container mx-auto px-4">
              <h2 className="font-display text-xl sm:text-2xl font-bold text-foreground uppercase tracking-tight mb-8">
                Produtos Relacionados
              </h2>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
                {relatedProducts.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            </div>
          </section>
        )}
      </main>

      <Footer />
      <WhatsAppFloat />
    </div>
  );
};

export default ProductDetail;
