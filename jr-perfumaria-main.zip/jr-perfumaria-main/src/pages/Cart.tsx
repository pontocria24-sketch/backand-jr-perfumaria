import { useCart } from "@/contexts/CartContext";
import { useStoreConfig } from "@/contexts/StoreConfigContext";
import { Button } from "@/components/ui/button";
import { Minus, Plus, Trash2, ArrowLeft, MessageCircle } from "lucide-react";
import { Link } from "react-router-dom";

const Cart = () => {
  const { items, removeItem, updateQuantity, clearCart, totalPrice } = useCart();
  const { config } = useStoreConfig();

  const buildWhatsAppMessage = () => {
    let message = `🛒 *Pedido ${config.storeName}*\n\n`;
    items.forEach((item, index) => {
      message += `${index + 1}. *${item.product.name}*\n`;
      message += `   Qtd: ${item.quantity} x R$ ${item.product.price.toFixed(2).replace(".", ",")}\n`;
      message += `   Subtotal: R$ ${(item.product.price * item.quantity).toFixed(2).replace(".", ",")}\n\n`;
    });
    message += `━━━━━━━━━━━━━━━\n`;
    message += `*Total: R$ ${totalPrice.toFixed(2).replace(".", ",")}*\n\n`;
    message += `📦 Aguardo confirmação do pedido!`;
    return encodeURIComponent(message);
  };

  const handleFinalize = () => {
    const url = `https://wa.me/${config.whatsappNumber}?text=${buildWhatsAppMessage()}`;
    window.open(url, "_blank");
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background px-4">
        <div className="text-center space-y-4">
          <h1 className="font-display text-3xl font-bold text-foreground">Carrinho Vazio</h1>
          <p className="text-muted-foreground">Adicione produtos para começar.</p>
          <Link to="/">
            <Button variant="hero">
              <ArrowLeft className="h-4 w-4 mr-2" /> Voltar às Compras
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <Link to="/" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition mb-6">
          <ArrowLeft className="h-4 w-4 mr-1" /> Continuar comprando
        </Link>

        <h1 className="font-display text-3xl font-bold text-foreground mb-6">Seu Carrinho</h1>

        <div className="space-y-4">
          {items.map((item) => (
            <div key={item.product.id} className="flex gap-4 p-4 bg-card rounded-lg border items-center">
              <img src={item.product.image} alt={item.product.name} className="h-20 w-20 rounded-md object-cover shrink-0" />
              <div className="flex-1 min-w-0">
                <h3 className="font-display font-semibold text-foreground truncate">{item.product.name}</h3>
                <p className="text-sm text-muted-foreground">R$ {item.product.price.toFixed(2).replace(".", ",")}</p>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => updateQuantity(item.product.id, item.quantity - 1)}>
                  <Minus className="h-3 w-3" />
                </Button>
                <span className="w-8 text-center font-semibold">{item.quantity}</span>
                <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => updateQuantity(item.product.id, item.quantity + 1)}>
                  <Plus className="h-3 w-3" />
                </Button>
              </div>
              <span className="font-bold text-primary font-display shrink-0">
                R$ {(item.product.price * item.quantity).toFixed(2).replace(".", ",")}
              </span>
              <Button variant="ghost" size="icon" onClick={() => removeItem(item.product.id)} className="text-destructive hover:text-destructive shrink-0">
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>

        <div className="mt-8 p-6 bg-card rounded-lg border space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-lg text-foreground">Total:</span>
            <span className="text-2xl font-bold text-primary font-display">
              R$ {totalPrice.toFixed(2).replace(".", ",")}
            </span>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={clearCart} className="flex-1">Limpar Carrinho</Button>
            <Button variant="hero" size="lg" onClick={handleFinalize} className="flex-1">
              <MessageCircle className="h-5 w-5 mr-2" /> Finalizar via WhatsApp
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
