import { useState, useMemo } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import BannerCarousel from "@/components/BannerCarousel";
import ProductCard from "@/components/ProductCard";
import CategoryFilter from "@/components/CategoryFilter";
import WhatsAppFloat from "@/components/WhatsAppFloat";
import { useStoreConfig } from "@/contexts/StoreConfigContext";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowRight } from "lucide-react";

const Index = () => {
  const { config } = useStoreConfig();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [sortBy, setSortBy] = useState("name");

  const filteredProducts = useMemo(() => {
    let products = [...config.products];

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      products = products.filter(
        (p) => p.name.toLowerCase().includes(q) || p.description.toLowerCase().includes(q)
      );
    }

    if (selectedCategory) {
      products = products.filter((p) => p.category === selectedCategory);
    }

    switch (sortBy) {
      case "price-asc":
        products.sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        products.sort((a, b) => b.price - a.price);
        break;
      case "name":
      default:
        products.sort((a, b) => a.name.localeCompare(b.name));
    }

    return products;
  }, [searchQuery, selectedCategory, sortBy, config.products]);

  const featuredProducts = config.products.filter((p) => p.featured);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header searchQuery={searchQuery} onSearchChange={setSearchQuery} />

      <main className="flex-1">
        {/* Banner - Full Width */}
        <BannerCarousel />

        {/* Category Section */}
        <section className="container mx-auto px-4 py-10">
          <h2 className="font-display text-lg sm:text-xl font-bold text-center text-foreground mb-6 uppercase tracking-wider">
            Qual categoria você procura?
          </h2>
          <CategoryFilter
            categories={config.categories}
            selected={selectedCategory}
            onSelect={setSelectedCategory}
          />
        </section>

        {/* Featured Products */}
        {!searchQuery && !selectedCategory && featuredProducts.length > 0 && (
          <section className="bg-muted/50 py-10 sm:py-14">
            <div className="container mx-auto px-4">
              <div className="flex items-center justify-between mb-8">
                <h2 className="font-display text-xl sm:text-2xl font-bold text-foreground uppercase tracking-tight">
                  Em Alta
                </h2>
                <button className="text-sm font-semibold text-primary hover:text-accent flex items-center gap-1 transition-colors">
                  Ver todos <ArrowRight className="h-4 w-4" />
                </button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-3 sm:gap-5">
                {featuredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* All Products */}
        <section className="container mx-auto px-4 py-10 sm:py-14">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
            <h2 className="font-display text-xl sm:text-2xl font-bold text-foreground uppercase tracking-tight">
              {searchQuery ? `Resultados para "${searchQuery}"` : "Todos os Perfumes"}
            </h2>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px] rounded-full bg-muted border-0 text-sm">
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Nome A-Z</SelectItem>
                <SelectItem value="price-asc">Menor Preço</SelectItem>
                <SelectItem value="price-desc">Maior Preço</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-3 sm:gap-5">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-20 text-muted-foreground">
              <p className="text-lg font-display">Nenhum produto encontrado.</p>
              <p className="text-sm mt-1">Tente outra busca ou categoria.</p>
            </div>
          )}
        </section>
      </main>

      <Footer />
      <WhatsAppFloat />
    </div>
  );
};

export default Index;
