export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  featured?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
}

export interface Banner {
  id: string;
  image: string;
  title: string;
  subtitle: string;
  cta: string;
  active: boolean;
}

export interface FooterConfig {
  storeName: string;
  description: string;
  email: string;
  whatsappDisplay: string;
  copyright: string;
}

export interface StoreConfig {
  logoUrl: string;
  storeName: string;
  whatsappNumber: string;
  banners: Banner[];
  categories: Category[];
  products: Product[];
  footer: FooterConfig;
}
