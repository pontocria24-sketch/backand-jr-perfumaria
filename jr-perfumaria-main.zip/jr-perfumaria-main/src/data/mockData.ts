import { Product, Category, Banner } from "@/types/store";
import perfume1 from "@/assets/perfume-1.jpg";
import perfume2 from "@/assets/perfume-2.jpg";
import perfume3 from "@/assets/perfume-3.jpg";
import perfume4 from "@/assets/perfume-4.jpg";
import perfume5 from "@/assets/perfume-5.jpg";
import perfume6 from "@/assets/perfume-6.jpg";
import perfume7 from "@/assets/perfume-7.jpg";
import perfume8 from "@/assets/perfume-8.jpg";
import banner1 from "@/assets/banner-1.jpg";
import banner2 from "@/assets/banner-2.jpg";

export const mockCategories: Category[] = [
  { id: "1", name: "Masculino", slug: "masculino" },
  { id: "2", name: "Feminino", slug: "feminino" },
  { id: "3", name: "Unissex", slug: "unissex" },
  { id: "4", name: "Importados", slug: "importados" },
  { id: "5", name: "Nacionais", slug: "nacionais" },
];

export const defaultBanners: Banner[] = [
  {
    id: "1",
    image: banner1,
    title: "Novas Fragrâncias",
    subtitle: "Descubra nossa coleção exclusiva de perfumes importados",
    cta: "Ver Coleção",
    active: true,
  },
  {
    id: "2",
    image: banner2,
    title: "Promoção Especial",
    subtitle: "Até 30% de desconto em perfumes selecionados",
    cta: "Aproveitar",
    active: true,
  },
];

export const mockProducts: Product[] = [
  {
    id: "1",
    name: "Eau de Parfum Royal",
    description: "Fragrância sofisticada com notas de sândalo, âmbar e baunilha para ocasiões especiais.",
    price: 189.90,
    image: perfume1,
    category: "masculino",
    featured: true,
  },
  {
    id: "2",
    name: "Floral Essence",
    description: "Perfume delicado com essência de rosas, jasmim e um toque de almíscar branco.",
    price: 159.90,
    image: perfume2,
    category: "feminino",
    featured: true,
  },
  {
    id: "3",
    name: "Night Oud Intense",
    description: "Oud autêntico combinado com especiarias orientais. Intenso e marcante para noites.",
    price: 249.90,
    image: perfume3,
    category: "importados",
    featured: true,
  },
  {
    id: "4",
    name: "Fresh Citrus",
    description: "Frescor cítrico com bergamota, limão siciliano e notas aquáticas revigorantes.",
    price: 119.90,
    image: perfume4,
    category: "unissex",
    featured: false,
  },
  {
    id: "5",
    name: "Velvet Rose",
    description: "Rosa aveludada com peônia e um fundo cremoso de musk. Elegância feminina pura.",
    price: 199.90,
    image: perfume5,
    category: "feminino",
    featured: true,
  },
  {
    id: "6",
    name: "Âmbar Dourado",
    description: "Âmbar quente com baunilha, canela e resinas preciosas. Caloroso e envolvente.",
    price: 139.90,
    image: perfume6,
    category: "nacionais",
    featured: false,
  },
  {
    id: "7",
    name: "Brisa do Mar",
    description: "Notas marinhas com sal, algas e madeira flutuante. Frescor natural e leve.",
    price: 99.90,
    image: perfume7,
    category: "unissex",
    featured: false,
  },
  {
    id: "8",
    name: "Black Leather",
    description: "Couro, tabaco e café numa composição audaciosa. Para homens de personalidade forte.",
    price: 219.90,
    image: perfume8,
    category: "masculino",
    featured: true,
  },
];
