import React, { createContext, useContext, useState, useCallback, useEffect } from "react";
import { StoreConfig, Banner, Category, Product, FooterConfig } from "@/types/store";
import { mockProducts, mockCategories, defaultBanners } from "@/data/mockData";
import { api } from "@/services/api";
import { toast } from "sonner";

const API_URL = import.meta.env.VITE_API_URL || "/api";

const defaultFooter: FooterConfig = {
  storeName: "JR Perfumaria",
  description: "As melhores fragrâncias para todos os momentos da sua vida.",
  email: "contato@jrperfumaria.com",
  whatsappDisplay: "(00) 00000-0000",
  copyright: "© 2026 JR Perfumaria. Todos os direitos reservados.",
};

const defaultConfig: StoreConfig = {
  logoUrl: "default",
  storeName: "JR Perfumaria",
  whatsappNumber: "5554991407378",
  banners: defaultBanners,
  categories: mockCategories,
  products: mockProducts,
  footer: defaultFooter,
};

interface StoreConfigContextType {
  config: StoreConfig;
  loading: boolean;
  updateStoreName: (name: string) => void;
  updateLogoUrl: (url: string) => void;
  updateWhatsappNumber: (number: string) => void;
  updateFooter: (footer: FooterConfig) => void;
  addBanner: (banner: Omit<Banner, "id">) => void;
  updateBanner: (id: string, banner: Partial<Banner>) => void;
  removeBanner: (id: string) => void;
  addCategory: (category: Omit<Category, "id">) => void;
  updateCategory: (id: string, category: Partial<Category>) => void;
  removeCategory: (id: string) => void;
  addProduct: (product: Omit<Product, "id">) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  removeProduct: (id: string) => void;
}

const StoreConfigContext = createContext<StoreConfigContextType | undefined>(undefined);

export const StoreConfigProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [config, setConfig] = useState<StoreConfig>(defaultConfig);
  const [loading, setLoading] = useState(!!API_URL);

  // Load from API on mount if VITE_API_URL is set
  useEffect(() => {
    if (!API_URL) return;

    const loadData = async () => {
      try {
        const [products, categories, banners, settingsRaw] = await Promise.all([
          api.products.getAll(),
          api.categories.getAll(),
          api.banners.getAll(),
          api.settings.get(),
        ]);

        const settings: Record<string, string> = {};
        settingsRaw.forEach((s) => (settings[s.key] = s.value));

        const footer: FooterConfig = settings.footer
          ? JSON.parse(settings.footer)
          : defaultFooter;

        setConfig({
          logoUrl: settings.logoUrl || defaultConfig.logoUrl,
          storeName: settings.storeName || defaultConfig.storeName,
          whatsappNumber: settings.whatsappNumber || defaultConfig.whatsappNumber,
          banners: banners.length ? banners : defaultBanners,
          categories: categories.length ? categories : mockCategories,
          products: products.length ? products : mockProducts,
          footer,
        });
      } catch (err) {
        console.error("Erro ao carregar dados da API, usando dados locais:", err);
        toast.error("Não foi possível conectar à API. Usando dados locais.");
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  // Helper: if API is configured, run the API call; always update local state
  const withApi = useCallback(async (fn: () => Promise<void>) => {
    if (!API_URL) return;
    try {
      await fn();
    } catch (err) {
      console.error("Erro na API:", err);
      toast.error("Erro ao salvar na API.");
    }
  }, []);

  const updateStoreName = useCallback((name: string) => {
    setConfig((prev) => ({ ...prev, storeName: name }));
    withApi(() => api.settings.upsert("storeName", name).then(() => {}));
  }, [withApi]);

  const updateLogoUrl = useCallback((url: string) => {
    setConfig((prev) => ({ ...prev, logoUrl: url }));
    withApi(() => api.settings.upsert("logoUrl", url).then(() => {}));
  }, [withApi]);

  const updateWhatsappNumber = useCallback((number: string) => {
    setConfig((prev) => ({ ...prev, whatsappNumber: number }));
    withApi(() => api.settings.upsert("whatsappNumber", number).then(() => {}));
  }, [withApi]);

  const updateFooter = useCallback((footer: FooterConfig) => {
    setConfig((prev) => ({ ...prev, footer }));
    withApi(() => api.settings.upsert("footer", JSON.stringify(footer)).then(() => {}));
  }, [withApi]);

  // Banners
  const addBanner = useCallback((banner: Omit<Banner, "id">) => {
    const tempId = Date.now().toString();
    setConfig((prev) => ({ ...prev, banners: [...prev.banners, { ...banner, id: tempId }] }));
    withApi(async () => {
      const [created] = await api.banners.create(banner);
      if (created) {
        setConfig((prev) => ({
          ...prev,
          banners: prev.banners.map((b) => (b.id === tempId ? created : b)),
        }));
      }
    });
  }, [withApi]);

  const updateBanner = useCallback((id: string, banner: Partial<Banner>) => {
    setConfig((prev) => ({
      ...prev,
      banners: prev.banners.map((b) => (b.id === id ? { ...b, ...banner } : b)),
    }));
    withApi(() => api.banners.update(id, banner).then(() => {}));
  }, [withApi]);

  const removeBanner = useCallback((id: string) => {
    setConfig((prev) => ({ ...prev, banners: prev.banners.filter((b) => b.id !== id) }));
    withApi(() => api.banners.delete(id));
  }, [withApi]);

  // Categories
  const addCategory = useCallback((category: Omit<Category, "id">) => {
    const tempId = Date.now().toString();
    setConfig((prev) => ({ ...prev, categories: [...prev.categories, { ...category, id: tempId }] }));
    withApi(async () => {
      const [created] = await api.categories.create(category);
      if (created) {
        setConfig((prev) => ({
          ...prev,
          categories: prev.categories.map((c) => (c.id === tempId ? created : c)),
        }));
      }
    });
  }, [withApi]);

  const updateCategory = useCallback((id: string, category: Partial<Category>) => {
    setConfig((prev) => ({
      ...prev,
      categories: prev.categories.map((c) => (c.id === id ? { ...c, ...category } : c)),
    }));
    withApi(() => api.categories.update(id, category).then(() => {}));
  }, [withApi]);

  const removeCategory = useCallback((id: string) => {
    setConfig((prev) => ({ ...prev, categories: prev.categories.filter((c) => c.id !== id) }));
    withApi(() => api.categories.delete(id));
  }, [withApi]);

  // Products
  const addProduct = useCallback((product: Omit<Product, "id">) => {
    const tempId = Date.now().toString();
    setConfig((prev) => ({ ...prev, products: [...prev.products, { ...product, id: tempId }] }));
    withApi(async () => {
      const [created] = await api.products.create(product);
      if (created) {
        setConfig((prev) => ({
          ...prev,
          products: prev.products.map((p) => (p.id === tempId ? created : p)),
        }));
      }
    });
  }, [withApi]);

  const updateProduct = useCallback((id: string, product: Partial<Product>) => {
    setConfig((prev) => ({
      ...prev,
      products: prev.products.map((p) => (p.id === id ? { ...p, ...product } : p)),
    }));
    withApi(() => api.products.update(id, product).then(() => {}));
  }, [withApi]);

  const removeProduct = useCallback((id: string) => {
    setConfig((prev) => ({ ...prev, products: prev.products.filter((p) => p.id !== id) }));
    withApi(() => api.products.delete(id));
  }, [withApi]);

  return (
    <StoreConfigContext.Provider
      value={{
        config,
        loading,
        updateStoreName,
        updateLogoUrl,
        updateWhatsappNumber,
        updateFooter,
        addBanner,
        updateBanner,
        removeBanner,
        addCategory,
        updateCategory,
        removeCategory,
        addProduct,
        updateProduct,
        removeProduct,
      }}
    >
      {children}
    </StoreConfigContext.Provider>
  );
};

export const useStoreConfig = () => {
  const context = useContext(StoreConfigContext);
  if (!context) throw new Error("useStoreConfig must be used within StoreConfigProvider");
  return context;
};
