import React, { createContext, useContext, useState, useCallback } from "react";

interface AuthContextType {
  user: { email: string; isAdmin: boolean } | null;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  register: (email: string, password: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<{ email: string; isAdmin: boolean } | null>(null);

  const login = useCallback((email: string, password: string) => {
    // Mock: admin@jr.com / admin123 is admin
    if (email === "admin@jr.com" && password === "admin123") {
      setUser({ email, isAdmin: true });
      return true;
    }
    // Any other valid-looking login
    if (email && password.length >= 4) {
      setUser({ email, isAdmin: false });
      return true;
    }
    return false;
  }, []);

  const register = useCallback((email: string, password: string) => {
    if (email && password.length >= 4) {
      setUser({ email, isAdmin: false });
      return true;
    }
    return false;
  }, []);

  const logout = useCallback(() => setUser(null), []);

  return (
    <AuthContext.Provider value={{ user, login, logout, register }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
};
